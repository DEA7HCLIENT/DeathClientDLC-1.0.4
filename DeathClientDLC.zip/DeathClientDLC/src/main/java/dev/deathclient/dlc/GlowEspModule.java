package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Soft outline through walls: a bright inner box plus a larger, fainter outer box, which reads
 * like a glow from a distance. Pure client-side line rendering, same technique as ESP/Tracers;
 * an earlier version tried to flip the entity's "glowing" flag directly, which real servers
 * keep overwriting, so it never actually showed anything.
 */
public class GlowEspModule extends Module implements WorldRender.WorldDrawable {
    public final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 4));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final BoolSetting items = add(new BoolSetting("Items", false));

    public GlowEspModule() { super("Glow ESP", Category.RENDER); }

    private boolean matches(Entity e) {
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof HostileEntity) return hostile.get();
        if (e instanceof LivingEntity) return passive.get();
        if (e instanceof ItemEntity) return items.get();
        return false;
    }

    @Override
    public void draw(WorldRenderContext ctx) {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;

        VertexConsumerProvider.Immediate buf = WorldRender.begin();
        var vc = buf.getBuffer(RenderLayer.getLines());
        var camera = WorldRender.entityCamera(ctx);
        for (Entity e : c.world.getEntities()) {
            if (e == p || !matches(e) || p.distanceTo(e) > range.get()) continue;
            if (e instanceof LivingEntity le && (!le.isAlive() || le.isSpectator())) continue;
            boolean friendly = e instanceof PlayerEntity;
            float r = friendly ? 1.0f : 0.95f, g = friendly ? 0.25f : 0.6f, b = 0.3f;
            WorldRender.box(ctx.matrixStack(), vc, camera, e.getBoundingBox().expand(0.04), r, g, b, 1.0f);
            WorldRender.box(ctx.matrixStack(), vc, camera, e.getBoundingBox().expand(0.22), r, g, b, 0.35f);
        }
        buf.draw();
    }

    @Override
    public void onTick(MinecraftClient c) { /* drawing only, no tick logic */ }
}
