package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Thin box outline around every matching entity in range, drawn through walls. */
public class TargetEspModule2 extends Module implements WorldRender.WorldDrawable {
    public final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 4));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final BoolSetting items = add(new BoolSetting("Items", false));

    public TargetEspModule2() { super("ESP", Category.RENDER); }

    private boolean matches(Entity e) {
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof HostileEntity) return hostile.get();
        if (e instanceof LivingEntity) return passive.get();
        if (e instanceof ItemEntity) return items.get();
        return false;
    }

    @Override
    public void draw(WorldRenderContext ctx) {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;

        VertexConsumerProvider.Immediate buf = WorldRender.begin();
        var vc = buf.getBuffer(RenderLayer.getLines());
        var camera = WorldRender.entityCamera(ctx);
        for (Entity e : c.world.getEntities()) {
            if (e == p || !matches(e) || p.distanceTo(e) > range.get()) continue;
            if (e instanceof LivingEntity le && (!le.isAlive() || le.isSpectator())) continue;
            boolean friendly = e instanceof PlayerEntity;
            WorldRender.box(ctx.matrixStack(), vc, camera, e.getBoundingBox().expand(0.05),
                    friendly ? 1.0f : 0.95f, friendly ? 0.2f : 0.55f, 0.25f, 1.0f);
        }
        buf.draw();
    }

    @Override
    public void onTick(MinecraftClient c) { /* drawing only, no tick logic */ }
}
