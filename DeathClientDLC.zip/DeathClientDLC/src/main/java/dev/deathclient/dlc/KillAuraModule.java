package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Attacks targets in range. Rotation eases toward the target over several ticks (capped turn
 * speed) instead of snapping there in one frame. Normal mode waits for the weapon cooldown;
 * HvH mode (for servers that allow cheats) ignores it and hits every tick.
 */
public class KillAuraModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 18, 4, 60, 1));
    public final BoolSetting hvh = add(new BoolSetting("HvH mode", false));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final NumberSetting targets = add(new NumberSetting("Targets", 1, 1, 5, 1));
    /** 1 = nearest first, 2 = lowest health first. */
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1));

    public KillAuraModule() { super("KillAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;

        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (p.distanceTo(le) <= range.get()) list.add(le);
        }
        if (list.isEmpty()) return;

        if ((int) priority.get() == 2) list.sort(Comparator.comparingDouble(LivingEntity::getHealth));
        else list.sort(Comparator.comparingDouble(p::distanceTo));

        LivingEntity primary = list.get(0);
        if (rotate.get()) turnToward(p, primary);

        float need = hvh.get() ? 0f : (float) cooldown.get();
        if (p.getAttackCooldownProgress(0.5f) < need) return;

        int count = Math.min(list.size(), (int) targets.get());
        for (int i = 0; i < count; i++) c.interactionManager.attackEntity(p, list.get(i));
        p.swingHand(Hand.MAIN_HAND);
    }

    /** Turns at most turnSpeed degrees this tick, taking the shorter way around. */
    private void turnToward(ClientPlayerEntity p, LivingEntity target) {
        Vec3d eye = p.getEyePos();
        Vec3d t = target.getBoundingBox().getCenter();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, h));

        float step = (float) turnSpeed.get();
        float yawDiff = MathHelper.wrapDegrees(wantYaw - p.getYaw());
        float pitchDiff = MathHelper.wrapDegrees(wantPitch - p.getPitch());

        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -step, step), -90f, 90f));
    }
}
