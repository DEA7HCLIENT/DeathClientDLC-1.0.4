package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Cross-hatched silhouette (box edges plus face diagonals) through walls, denser than plain ESP
 * so it reads closer to a filled "chams" shape without needing an unproven filled-quad renderer.
 */
public class ChamsModule extends Module implements WorldRender.WorldDrawable {
    public final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 4));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public ChamsModule() { super("Chams", Category.RENDER); }

    @Override
    public void draw(WorldRenderContext ctx) {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;

        VertexConsumerProvider.Immediate buf = WorldRender.begin();
        var vc = buf.getBuffer(RenderLayer.getLines());
        var camera = WorldRender.entityCamera(ctx);
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (p.distanceTo(le) > range.get()) continue;
            WorldRender.cross(ctx.matrixStack(), vc, camera, le.getBoundingBox().expand(0.05), 0.3f, 0.75f, 1.0f, 1.0f);
        }
        buf.draw();
    }

    @Override
    public void onTick(MinecraftClient c) { /* drawing only, no tick logic */ }
}
