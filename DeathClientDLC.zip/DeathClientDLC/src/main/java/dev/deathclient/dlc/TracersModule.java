package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Lines from your view to nearby entities (no particles). */
public class TracersModule extends Module implements WorldRender.WorldDrawable {
    public final NumberSetting range = add(new NumberSetting("Range", 24, 8, 64, 4));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public TracersModule() { super("Tracers", Category.VISUALS); }

    @Override
    public void draw(WorldRenderContext ctx) {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;

        VertexConsumerProvider.Immediate buf = WorldRender.begin();
        var vc = buf.getBuffer(RenderLayer.getLines());
        var camera = WorldRender.entityCamera(ctx);
        var from = p.getEyePos();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (p.distanceTo(le) > range.get()) continue;
            WorldRender.line(ctx.matrixStack(), vc, camera, from, le.getBoundingBox().getCenter(), 1.0f, 0.2f, 0.25f, 0.8f);
        }
        buf.draw();
    }

    @Override
    public void onTick(MinecraftClient c) { /* drawing only */ }
}
